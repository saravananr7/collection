<!-- eslint-disable no-unused-vars -->
<template>
  <div>
    <AppBar />
  <router-view/></div>
</template>

<script>
import AppBar from "../AppBar.vue";
export default {
    data: () => ({
        
    }),
    components:{
        AppBar
    }
}

</script>
