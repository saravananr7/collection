export default{
collectionurl:"http://192.168.5.95:5111"

}