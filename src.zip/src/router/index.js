import LayoutSrc from "@/components/Layout/LayoutSrc.vue"
import DashboardPage from "@/views/Dashboard/DashBoard.vue";
import Vue from "vue";
import VueRouter from "vue-router";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    redirect: "/collection",
    name: "appbar",
    component: LayoutSrc,
    children: [
      {
        path: "/collection",
        // redirect: "/collection",
        name: "dashboard",
        component: DashboardPage,
      },
      // {
      //   path: "/stock",
      //   name: "single page stock",
      // },
      // { path: "*", redirect: "/collection" },
    ],
  },
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
  scrollBehavior() {
    window.scrollTo(0, 0);
  },
});

export default router;
