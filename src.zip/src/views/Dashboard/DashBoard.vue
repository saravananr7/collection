<template>
  <v-container class="mt-0">
    <v-snackbar
      transition="slide-x-reverse-transition"
      v-model="snakebar"
      timeout="6000"
      :value="true"
      :color="snakebarcolor"
      top
      right
      outlined
      absolute
      text-color="white"
    >
      <v-icon class="mr-2" :color="snakebarcolor">mdi-alert-outline</v-icon>
      {{ msg }}
      <v-icon
        @click="snakebar = false"
        :color="snakebarcolor"
        class="float-right"
        >mdi-close-circle</v-icon
      >
    </v-snackbar>
    <p class="font-weight-bold caption">Collection</p>
    <v-row>
      <v-col cols="12" md="9" class="mt-3">
        <div class="d-flex align-center">
          <v-badge
            :content="collections.length ? collections.length : 0"
            :value="collections.length ? collections.length : 0"
            overlap
          >
            <p class="title font-weight-bold">Top Collections</p>
          </v-badge>
          <v-spacer></v-spacer>
          <v-text-field 
            v-model="searchkeyfield"
            prepend-inner-icon="mdi-magnify"
            style="max-width: 270px; font-size: 13px"
            label="Search"
            single-line
            filled
            dense
            rounded
          />
        </div>
        <v-divider></v-divider>
        <v-row class="mt-2 d-flex">
          <v-col
          xs="12"
          sm="12"
            md="6"
            lg="4"
            class="mb-2"
            v-for="(item, i) in MobsearchItem"
            :key="i"
          >
            <v-card
              class="elevation-0 rounded"
              outlined
              style="cursor: pointer"
            >
              <v-row class="mt-1 mx-2 mb-1">
                <v-col>
                  <v-img
                    height="50px"
                    width="50px"
                    class="rounded"
                    :src="modifyurl(item.basket_img)"
                  />
                </v-col>
                <v-col>
                  <v-chip
                    class="px-4 py-0 mx-auto float-end"
                    small
                    :style="{
                      fontSize: '12px',
                      color: item.access === 'free' ? 'green' : 'blue',
                      background:
                        item.access === 'free' ? '#d3f5c6' : '#E4EfE8',
                    }"
                    >{{ item.access }}</v-chip
                  ></v-col
                > </v-row
              ><v-card-title
                class="text-uppercase pa-1 ms-3"
                style="font-size: 16px"
                >{{ item.basket_title }}
              </v-card-title>
              <div class="ms-3 mb-5">
                <v-chip
                  class="font-weight-bold text--secondary mx-1 text-capitalize"
                  small
                  style="font-size: 12px"
                  v-for="(j, l) in item.etfs_weights"
                  :key="l"
                  >{{ j }}</v-chip
                >
              </div>
              <v-row class="ms-2 font-weight-bold" style="font-size: 13px">
                <v-col>
                  <span style="color: gray">MIN. INVEST</span>
                  <p>{{ item.price }}</p>
                </v-col>
                <v-col class="end">
                  <span style="color: gray">TOTAL STOCKS</span>
                  <p>{{ item.stockcount }} stocks</p>
                </v-col>
              </v-row>
            </v-card></v-col
          >
        </v-row>
      </v-col></v-row
    >
  </v-container>
</template>

<script>
import apiurl from "@/apiurl";

export default {
  data: () => ({
    collections: [],
    collectload: false,
    snakebar: false,
    snakebarcolor: "#000",
    msg: "",
    searchkeyfield:"",
    apiurlcollection: `${apiurl.collectionurl}`,
  }),
  methods: {
    collection() {
      this.collections = [];
      this.collectload = true;
      const axios = require("axios");
      let config = {
        method: "post",
        maxBodyLength: Infinity,
        url: `${apiurl.collectionurl}/collectiondetails`,
        headers: {},
      };
      var axiosThis = this;
      axios
        .request(config)
        .then((response) => {
          this.collectload = false;
          if (response.data.stat == "ok" && response.data.msg != "No data") {
            axiosThis.collections = response.data.msg;
          } else {
            axiosThis.snakebar = true;
            axiosThis.collectload = false;
            axiosThis.snakebarcolor = "error";
            axiosThis.msg = response.data.msg;
          }
        })
        .catch((error) => {
          console.log(error);
          axiosThis.snakebar = true;
          axiosThis.collectload = false;
          axiosThis.snakebarcolor = "error";
          axiosThis.msg = error;
        });
    },
    modifyurl(itemppath) {
      const modifyurl =
        this.apiurlcollection + "/static/" + itemppath.split("/static/")[1];
      return modifyurl;
    },
  },
  computed: {
    MobsearchItem() {
        return this.collections.filter((post) => {
            return post.basket_title.toLowerCase().includes(
                this.searchkeyfield.toLowerCase()
            );
        });
    }
  },
  mounted() {
    this.collection();
  },
};
</script>
